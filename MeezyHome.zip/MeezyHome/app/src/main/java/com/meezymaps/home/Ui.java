package com.meezymaps.home;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Builds the tiles in code: no layout files, no images, stays light. */
final class Ui {

    private Ui() {}

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(int color, int radius, int strokeW, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (strokeW > 0) g.setStroke(strokeW, strokeColor);
        return g;
    }

    /** A focusable tile: coloured card with the app's icon (or a big letter) and a label. */
    static LinearLayout tile(Context c, String label, int color, Drawable icon,
                             int widthDp, int heightDp, View.OnClickListener onClick) {
        final int r = dp(c, 18);
        final GradientDrawable normal = rounded(color, r, 0, 0);
        final GradientDrawable focused = rounded(color, r, dp(c, 4), Color.WHITE);

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackground(normal);
        box.setFocusable(true);
        box.setClickable(true);
        box.setOnClickListener(onClick);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, widthDp), dp(c, heightDp));
        lp.setMargins(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14));
        box.setLayoutParams(lp);

        if (icon != null) {
            ImageView iv = new ImageView(c);
            iv.setImageDrawable(icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            box.addView(iv, new LinearLayout.LayoutParams(dp(c, heightDp - 70), dp(c, heightDp - 70)));
        } else {
            TextView letter = new TextView(c);
            letter.setText(label.substring(0, 1));
            letter.setTextColor(Color.WHITE);
            letter.setTextSize(48);
            letter.setGravity(Gravity.CENTER);
            box.addView(letter);
        }

        TextView name = new TextView(c);
        name.setText(label);
        name.setTextColor(Color.WHITE);
        name.setTextSize(20);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(c, 8), 0, 0);
        box.addView(name);

        // Grow slightly and show a white outline when the remote highlights it
        box.setOnFocusChangeListener((v, hasFocus) -> {
            v.setBackground(hasFocus ? focused : normal);
            float s = hasFocus ? 1.08f : 1f;
            v.animate().scaleX(s).scaleY(s).setDuration(120).start();
        });
        return box;
    }
}
