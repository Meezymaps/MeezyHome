package com.meezymaps.home;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * "Speed up" screen:
 *  - shows free memory
 *  - Boost: closes apps running in the background
 *  - list of apps: tap one to open its system page (Force stop / Clear cache / Uninstall / Disable)
 */
public class SpeedActivity extends Activity {

    private TextView memText;
    private final List<App> apps = new ArrayList<>();

    private static final class App {
        String label, pkg;
        boolean system;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0F1A);
        int pad = Ui.dp(this, 30);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Speed up");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        root.addView(title);

        memText = new TextView(this);
        memText.setTextColor(0xFFB8C4E0);
        memText.setTextSize(18);
        memText.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        root.addView(memText);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.addView(Ui.tile(this, "Boost", 0xFF0F9D58, null, 200, 110, v -> boost()));
        buttons.addView(Ui.tile(this, "All app settings", 0xFF3A4766, null, 260, 110, v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
            } catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { }
            }
        }));
        root.addView(buttons);

        TextView hint = new TextView(this);
        hint.setText("Pick an app to Force stop, Clear cache, Disable or Uninstall it:");
        hint.setTextColor(0xFF8FA0C8);
        hint.setTextSize(16);
        hint.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 6));
        root.addView(hint);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        list.setItemsCanFocus(true);
        list.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return apps.size(); }
            @Override public Object getItem(int i) { return apps.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, ViewGroup parent) {
                final App a = apps.get(i);
                LinearLayout row = Ui.tile(SpeedActivity.this,
                        a.label + (a.system ? "   (built-in)" : ""),
                        0xFF1E2740, AppLauncher.icon(SpeedActivity.this, a.pkg), 0, 0,
                        v -> openAppInfo(a.pkg));
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(SpeedActivity.this, 16), 0, 0, 0);
                // icon smaller in list rows
                if (row.getChildCount() > 1) {
                    View icon = row.getChildAt(0);
                    icon.setLayoutParams(new LinearLayout.LayoutParams(
                            Ui.dp(SpeedActivity.this, 44), Ui.dp(SpeedActivity.this, 44)));
                    View name = row.getChildAt(1);
                    name.setPadding(Ui.dp(SpeedActivity.this, 16), 0, 0, 0);
                }
                ListView.LayoutParams lp = new ListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(SpeedActivity.this, 64));
                row.setLayoutParams(lp);
                return row;
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        updateMemory();
    }

    private void updateMemory() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long freeMb = mi.availMem / (1024 * 1024);
        long totalMb = mi.totalMem / (1024 * 1024);
        memText.setText("Free memory: " + freeMb + " MB of " + totalMb + " MB"
                + (mi.lowMemory ? "   — running low!" : ""));
    }

    /** Closes background apps (what Android allows a normal app to do). */
    private void boost() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo before = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(before);

        PackageManager pm = getPackageManager();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (ai.packageName.equals(getPackageName())) continue;
            try { am.killBackgroundProcesses(ai.packageName); } catch (Exception ignored) { }
        }

        memText.postDelayed(() -> {
            ActivityManager.MemoryInfo after = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(after);
            long freed = Math.max(0, (after.availMem - before.availMem) / (1024 * 1024));
            Toast.makeText(this, "Closed background apps — freed about " + freed + " MB",
                    Toast.LENGTH_LONG).show();
            updateMemory();
        }, 1500);
    }

    private void openAppInfo(String pkg) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + pkg));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "This TV doesn't allow opening app settings", Toast.LENGTH_LONG).show();
        }
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        seen.add(getPackageName());
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (!seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.system = (ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                apps.add(a);
            }
        }
        // your own installed apps first, then built-in ones
        Collections.sort(apps, (x, y) -> x.system != y.system
                ? (x.system ? 1 : -1)
                : x.label.compareToIgnoreCase(y.label));
        ListView lv = findListView(getWindow().getDecorView());
        if (lv != null) ((BaseAdapter) lv.getAdapter()).notifyDataSetChanged();
    }

    private static ListView findListView(View v) {
        if (v instanceof ListView) return (ListView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                ListView r = findListView(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }
}
