package com.meezymaps.home;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Meezy Home: a light TV home screen with YouTube, Netflix and Chrome. */
public class MainActivity extends Activity {

    // TV versions first, phone versions as fallback
    private static final String[] YOUTUBE = {
            "com.google.android.youtube.tv", "com.google.android.youtube.googletv",
            "com.google.android.youtube"};
    private static final String[] NETFLIX = {"com.netflix.ninja", "com.netflix.mediaclient"};
    private static final String[] CHROME = {"com.android.chrome", "com.chrome.beta"};

    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private TextView clock;
    private LinearLayout row;
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault());

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            Date now = new Date();
            clock.setText(timeFmt.format(now) + "   " + dateFmt.format(now));
            // update once a minute only: keeps CPU use near zero
            clockHandler.postDelayed(this, 60_000 - (System.currentTimeMillis() % 60_000));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF0B0F1A, 0xFF1B2440});
        root.setBackground(bg);
        int pad = Ui.dp(this, 40);
        root.setPadding(pad, pad, pad, pad);

        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(30);
        root.addView(clock);

        TextView title = new TextView(this);
        title.setText("Meezy Home");
        title.setTextColor(0xFFB8C4E0);
        title.setTextSize(18);
        title.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 30));
        root.addView(title);

        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        root.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView credit = new TextView(this);
        credit.setText("by Meezy Maps");
        credit.setTextColor(0xFF6B7899);
        credit.setTextSize(14);
        root.addView(credit);

        setContentView(root);
    }

    /** Rebuild tiles each time we come back, so newly installed apps show their icon. */
    private void buildTiles() {
        row.removeAllViews();

        final String yt = AppLauncher.firstInstalled(this, YOUTUBE);
        final String nf = AppLauncher.firstInstalled(this, NETFLIX);
        final String ch = AppLauncher.firstInstalled(this, CHROME);

        View first = Ui.tile(this, "YouTube", 0xFFCC0000, AppLauncher.icon(this, yt), 220, 200,
                v -> AppLauncher.open(this, yt, YOUTUBE[0]));
        row.addView(first);

        row.addView(Ui.tile(this, "Netflix", 0xFF141414, AppLauncher.icon(this, nf), 220, 200,
                v -> AppLauncher.open(this, nf, NETFLIX[0])));

        // If Chrome isn't on the TV, open whatever browser is installed
        row.addView(Ui.tile(this, ch != null ? "Chrome" : "Browser", 0xFF1A73E8,
                AppLauncher.icon(this, ch), 220, 200,
                v -> {
                    if (ch != null) AppLauncher.open(this, ch, CHROME[0]);
                    else AppLauncher.openWeb(this, "https://www.google.com");
                }));

        row.addView(Ui.tile(this, "All apps", 0xFF3A4766, null, 220, 200,
                v -> startActivity(new Intent(this, AllAppsActivity.class))));

        row.addView(Ui.tile(this, "Settings", 0xFF2E3A55, null, 220, 200,
                v -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) { }
                }));

        first.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        buildTiles();
        clockHandler.removeCallbacks(tick);
        tick.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        clockHandler.removeCallbacks(tick); // nothing runs while you're in another app
    }

    @Override
    public void onBackPressed() {
        // Home screen: Back does nothing here
    }
}
