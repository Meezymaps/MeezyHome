package com.meezymaps.home;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Grid of every installed app. GridView only creates the tiles on screen, so it stays light. */
public class AllAppsActivity extends Activity {

    private static final class App {
        String label, pkg;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final List<App> apps = loadApps();

        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 200));
        grid.setStretchMode(GridView.STRETCH_SPACING);
        grid.setBackgroundColor(0xFF0B0F1A);
        int pad = Ui.dp(this, 30);
        grid.setPadding(pad, pad, pad, pad);
        grid.setClipToPadding(false);
        grid.setDrawSelectorOnTop(false);
        grid.setSelector(android.R.color.transparent);

        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return apps.size(); }
            @Override public Object getItem(int i) { return apps.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override public View getView(int i, View convert, ViewGroup parent) {
                final App a = apps.get(i);
                View t = Ui.tile(AllAppsActivity.this, a.label, 0xFF26304A,
                        AppLauncher.icon(AllAppsActivity.this, a.pkg), 170, 150,
                        v -> AppLauncher.open(AllAppsActivity.this, a.pkg, a.pkg));
                t.setLayoutParams(new GridView.LayoutParams(Ui.dp(AllAppsActivity.this, 170),
                        Ui.dp(AllAppsActivity.this, 150)));
                return t;
            }
        });

        setContentView(grid);
    }

    private List<App> loadApps() {
        PackageManager pm = getPackageManager();
        List<App> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        seen.add(getPackageName());

        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (!seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.label = String.valueOf(ri.loadLabel(pm));
                out.add(a);
            }
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }
}
