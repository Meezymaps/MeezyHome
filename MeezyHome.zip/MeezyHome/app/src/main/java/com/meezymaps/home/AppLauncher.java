package com.meezymaps.home;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.Toast;

/** Small helper for finding and opening installed apps. No libraries needed. */
final class AppLauncher {

    private AppLauncher() {}

    /** TV-style launch intent first, then normal phone-style one. */
    static Intent launchIntent(Context c, String pkg) {
        PackageManager pm = c.getPackageManager();
        Intent i = null;
        try {
            i = pm.getLeanbackLaunchIntentForPackage(pkg);
        } catch (Throwable ignored) {
            // older Android without leanback support
        }
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        return i;
    }

    /** Returns the first package from the list that is installed and launchable. */
    static String firstInstalled(Context c, String[] pkgs) {
        for (String p : pkgs) {
            if (launchIntent(c, p) != null) return p;
        }
        return null;
    }

    static Drawable icon(Context c, String pkg) {
        if (pkg == null) return null;
        try {
            PackageManager pm = c.getPackageManager();
            Drawable banner = null;
            try {
                banner = pm.getApplicationBanner(pkg);
            } catch (Throwable ignored) { }
            return banner != null ? banner : pm.getApplicationIcon(pkg);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    /** Opens the app, or the Play Store page for it if it isn't installed. */
    static void open(Context c, String pkg, String storePkg) {
        Intent i = pkg != null ? launchIntent(c, pkg) : null;
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return;
        }
        try {
            Intent store = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + storePkg));
            store.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(store);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(c, "Not installed, and no app store found", Toast.LENGTH_LONG).show();
        }
    }

    /** Opens any web browser on the TV with the given address. */
    static void openWeb(Context c, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(c, "No web browser installed", Toast.LENGTH_LONG).show();
        }
    }
}
