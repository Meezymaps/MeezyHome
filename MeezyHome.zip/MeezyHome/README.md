# Meezy Home — by Meezy Maps

A light home screen for Android / Google TV with big remote-friendly tiles:
YouTube · Netflix · Chrome (or any browser) · All apps · Settings.

- No extra libraries, no images: the APK is tiny and uses almost no memory.
- Uses each app's own TV banner/icon.
- If an app isn't installed, its tile opens the Play Store page for it.
- The clock only updates once a minute and stops while you're in another app.

## Get the APK (free, no Android Studio needed)

1. Go to github.com → **New repository** → name it `MeezyHome` → Create.
2. Click **uploading an existing file**, drag in everything from this folder
   (including the `.github` folder) → **Commit changes**.
3. Open the **Actions** tab → wait for **Build APK** to turn green (about 3–4 min).
4. Click the run → under **Artifacts** download **MeezyHome-apk** → unzip → `app-debug.apk`.

(Or open the folder in Android Studio and press Build → Build APK.)

## Put it on the TV

1. Copy `app-debug.apk` to a USB stick, plug it into the TV.
2. On the TV: Settings → Device Preferences → Security → allow **Unknown sources**
   for your file manager (install "File Commander" or "X-plore" from Play Store if needed).
3. Open the APK with the file manager → Install.
4. Open **Meezy Home** from the apps list.
5. To make it the home screen: press the Home button — if the TV asks which home app to use,
   pick **Meezy Home → Always**. (Some Google TV models don't ask; then just open it from the apps row.)

Netflix only plays if the Netflix app on the TV is installed and supported on that TV.
